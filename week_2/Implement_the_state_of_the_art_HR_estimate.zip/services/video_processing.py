import cv2
import numpy as np
import mediapipe as mp
from scipy.signal import butter, filtfilt
from collections import deque
import threading
import time
import queue
from deepface import DeepFace
import logging


# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# constants 
BUFFER_SIZE = 60
FPS = 30

# data buffers  
rgb_buffer = {'r': deque(maxlen=BUFFER_SIZE), 'g': deque(maxlen=BUFFER_SIZE), 'b': deque(maxlen=BUFFER_SIZE)}
hr_values = deque(maxlen=10)

# threading & streaming  
rgb_clients = []
current_rgb_data = {'r': 0, 'g': 0, 'b': 0, 'heart_rate': 75.0, 'emotion': 'Unknown'}
rgb_data_lock = threading.Lock()
latest_emotion = 'Unknown'
emotion_lock = threading.Lock()

# kalman filter parameters based on Bayesian Inference
# Inference: https://en.wikipedia.org/wiki/Kalman_filter 
# or https://www.youtube.com/playlist?list=PLX2gX-ftPVXU3oUFNATxGXY90AULiqnWT
kalman_hr = 75.0
kalman_p = 1.0
kalman_q = 0.01
kalman_r = 1.0

# Model initialization
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1, refine_landmarks=True)


# ====== 1. Face Mask Creation ======
def create_face_mask_with_colors(image):
    """
    Detects a face in an image using MediaPipe Face Mesh, creates a convex hull mask
    around the face landmarks, and returns a new image where everything
    outside the face mask is blacked out.
    """
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb_image)

    mask = np.zeros(image.shape[:2], dtype=np.uint8)

    if results.multi_face_landmarks:
        for face_landmarks in results.multi_face_landmarks:
            points = np.array([(int(landmark.x * image.shape[1]), int(landmark.y * image.shape[0]))
                               for landmark in face_landmarks.landmark], dtype=np.int32)
            
            hull = cv2.convexHull(points)

            cv2.fillPoly(mask, [hull], 255)

    masked_face = cv2.bitwise_and(image, image, mask=mask)
    return masked_face


# ====== 2. Skin Segmentation ======
def skin_segmentation(face_mask):
    """
    This function converts the BGR `face_mask` to the HSV color space
    to isolate skin-tone pixels base odn a predefined range of
    Hue, Saturation, and Value. It filters out non-skin pixels
    like eyes, eyebrows, and mouth.
    """
    hsv = cv2.cvtColor(face_mask, cv2.COLOR_BGR2HSV)

    lower_skin = np.array([0, 20, 70], dtype=np.uint8)
    upper_skin = np.array([20, 255, 255], dtype=np.uint8)
    
    skin_mask = cv2.inRange(hsv, lower_skin, upper_skin)
    return cv2.bitwise_and(face_mask, face_mask, mask=skin_mask)


# ====== 3. Signal Processing Functions ======
def blackout_outside_dynamic_threshold(frame, lower_factor=0.48, upper_factor=1.74):
    """Filters out pixels that are too dark or too bright based on a dynamic threshold."""
    gray_image = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    non_zero_pixels = gray_image[gray_image != 0]

    average_value = np.median(non_zero_pixels) if non_zero_pixels.size > 0 else 0

    lower_threshold = max(0, int(average_value * lower_factor))
    upper_threshold = min(255, int(average_value * upper_factor))

    mask = (gray_image >= lower_threshold) & (gray_image <= upper_threshold)

    updated_frame = np.zeros_like(frame)
    updated_frame[mask] = frame[mask]

    return updated_frame


# ====== 4. RGB Signal Extraction ======
def extract_rgb_signals(frame):
    """Extracts mean RGB values from the given frame."""
    face_pixels = frame[frame.sum(axis=2) > 0]

    if len(face_pixels) == 0:
        logger.debug("No face pixels detected")
        return (0, 0, 0)
    
    mean_r = int(np.mean(face_pixels[:, 2]))
    mean_g = int(np.mean(face_pixels[:, 1]))
    mean_b = int(np.mean(face_pixels[:, 0]))

    logger.debug(f"RGB signals: R={mean_r}, G={mean_g}, B={mean_b}")
    return (mean_r, mean_g, mean_b)


# ======= 5. Pulse Extraction Methods ======
def chrom_method(r_signal, g_signal, b_signal):
    """Chrominance-based method to extract pulse signal."""
    X = 3 * np.array(r_signal) - 2 * np.array(g_signal)
    Y = 1.5 * np.array(g_signal) - 1.5 * np.array(b_signal)
    return X + Y


# ======= 6. Heart Rate Computation ======
def set_kalman_defaults():
    """Clears data buffers and resets kalman filter parameters."""
    global kalman_hr, kalman_p
    rgb_buffer['r'].clear()
    rgb_buffer['g'].clear()
    rgb_buffer['b'].clear()
    hr_values.clear()

    kalman_hr = 75.0
    kalman_p = 1.0

    with emotion_lock:
        global latest_emotion
        latest_emotion = 'Unknown'


def bandpass_filter(signal, lowcut=0.6, highcut=3.0, fs=FPS, order=5):
    nyquist = 0.5 * fs

    low, high = lowcut / nyquist, highcut / nyquist

    b, a = butter(order, [low, high], btype='band')

    return filtfilt(b, a, signal) if len(signal) > order else signal


def compute_heart_rate(signal):
    global kalman_hr, kalman_p

    if len(signal) < BUFFER_SIZE:
        logger.debug(f"Buffer not full: {len(signal)}/{BUFFER_SIZE}, returning default HR: {kalman_hr}")
        return kalman_hr
    
    filtered_signal = bandpass_filter(signal)

    # FFT 
    fft_spectrum = np.fft.rfft(filtered_signal)
    freqs = np.fft.rfftfreq(len(filtered_signal), d=1/FPS)

    # Find peak frequency in the valid range
    valid_range = (freqs >= 0.92) & (freqs <= 2.0)
    if not any(valid_range):
        logger.debug(f"No valid frequencies in range, returning current HR: {kalman_hr}")
        return kalman_hr
    peak_freq = freqs[valid_range][np.argmax(np.abs(fft_spectrum[valid_range]))]

    # Calculate BPM
    bpm = peak_freq * 60
    logger.debug(f"Computed BPM: {bpm}")
    if bpm < 40:
        logger.debug(f"BPM {bpm} too low, returning current HR: {kalman_hr}")
        bpm = kalman_hr

    # Smooth BPM using moving average
    hr_values.append(bpm)
    bpm_smoothed = np.mean(hr_values)

    # Kalman filter update
    kalman_p += kalman_q
    kalman_k = kalman_p / (kalman_p + kalman_r)
    kalman_hr = kalman_hr + kalman_k * (bpm_smoothed - kalman_hr)
    kalman_p = (1 - kalman_k) * kalman_p
    logger.debug(f"Smoothed HR: {kalman_hr}")

    return kalman_hr



# ====== RGB Data Broadcasting ======
def broadcast_rgb_data(data):
    """
    Broadcasts a data packet to all connected clients and cleans up
    disconnected clients.
    """
    with rgb_data_lock:
        global current_rgb_data
        current_rgb_data = data

        logger.debug(f"Broadcasting RGB data: {data}")

        disconnected_clients = []

        for client_queue in rgb_clients:
            try:
                client_queue.put(data, timeout=0.1)
            except queue.Full:
                disconnected_clients.append(client_queue)

        for client in disconnected_clients:
            rgb_clients.remove(client)


# ====== Emotion Detection ======
def detect_emotion(image):
    """
    Analyzes a single image using DeepFace to determine the dominant emotion.

    Args:
        image: The input image (as a NumPy array) containing a face.

    Returns:
        A string representing the dominant emotion (e.g., 'happy', 'sad')
        or "Unknown" if detection fails or an error occurs.
    """
    try:
        result = DeepFace.analyze(image, actions=['emotion'], enforce_detection=False)
        emotion = result[0]['dominant_emotion']
        return emotion
    except Exception as e:
        logger.error(f"Error detecting emotion: {e}")
        return "Unknown"


def detect_emotion_thread(frame_queue, stop_event):
    """
    This function runs in a background thread.
    It continuously gets frames from a queue, runs the slow detect_emotion function, 
    and safely updates a global variable with the result.
    This stops the slow AI analysis from lagging the main video thread.
    """
    while not stop_event.is_set():
        try:
            frame = frame_queue.get(timeout=1.0)
            emotion = detect_emotion(frame)

            with emotion_lock:
                global latest_emotion
                latest_emotion = emotion

            logger.debug(f"Detected emotion: {emotion}")
            frame_queue.task_done()
        except queue.Empty:
            continue


# ====== Main Video Processing Function ======
def generate_gray_frames(path):
    """
    Main generator function that processes a video source (file or camera),
    performs rPPG (heart rate) and emotion analysis,
    and yields JPEG frames for web streaming.
    """
    # Open the video source
    cap = cv2.VideoCapture(path)
    frame_count = 0

    # --- Emotion detection threading setup ---
    # A queue to pass frames to the emotion thread (maxsize=1 to only process latest)
    frame_queue = queue.Queue(maxsize=1)
    # An event to signal the thread to stop
    stop_event = threading.Event()
    # Create and start the background thread for emotion detection
    emotion_thread = threading.Thread(target=detect_emotion_thread, args=(frame_queue, stop_event))
    emotion_thread.daemon = True  # Ensure thread exits when main program does
    emotion_thread.start()

    try:
        # Main loop: Read frames while the video source is open
        while cap.isOpened():
            success, frame = cap.read()

            if not success:
                logger.debug("Failed to read frame or end of video")
                break  # Exit loop if video ends or fails

            frame_count += 1

            # --- Face Detection & Masking Pipeline ---
            # 1. Detect face and create a mask (blackout background)
            face_mask = create_face_mask_with_colors(frame)

            # --- Case 1: No face detected ---
            if face_mask is None or not np.any(face_mask):
                logger.debug("No face detected in frame")
                # Draw "No face" text on the original frame
                cv2.putText(frame, "No face detected", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                # Prepare empty data to broadcast
                rgb_data = {'r': 0, 'g': 0, 'b': 0, 'heart_rate': 0.0, 'emotion': 'Unknown'}
            
            # --- Case 2: Face detected ---
            else:
                # 2. Refine mask to only skin pixels (remove eyes, mouth)
                skin_segmented = skin_segmentation(face_mask)
                # 3. Filter out pixels that are too bright/dark
                face = blackout_outside_dynamic_threshold(skin_segmented)
                # 4. Extract the average R, G, B values from the clean skin pixels
                mean_r, mean_g, mean_b = extract_rgb_signals(face)

                # --- Heart Rate Calculation ---
                # Add new RGB values to the signal buffers
                rgb_buffer["r"].append(mean_r)
                rgb_buffer["g"].append(mean_g)
                rgb_buffer["b"].append(mean_b)
                # 5. Create a pulse signal using the CHROM method
                pulse_signal = chrom_method(rgb_buffer['r'], rgb_buffer['g'], rgb_buffer['b'])
                # 6. Compute the heart rate from the pulse signal (includes FFT & Kalman filter)
                heart_rate = compute_heart_rate(pulse_signal)

                # Show "Detecting" while Kalman filter is stabilizing (initial value is 75)
                if heart_rate == 75:
                    heart_rate = "Detecting"
                
                # --- Other Computations ---
                # 7. Estimate body temperature (simple linear formula)
                estimated_temp = 36 + 0.01 * mean_r - 0.005 * mean_g + 0.008 * mean_b

                # --- Emotion Detection (Threading) ---
                # Every 5 frames, send a frame to the emotion thread
                if frame_count % 5 == 0:
                    try:
                        # Put the frame in the queue (non-blocking with timeout)
                        frame_queue.put(frame, timeout=0.1)
                    except queue.Full:
                        # If queue is full (emotion thread is busy), just skip this frame
                        logger.debug("Emotion queue full, skipping frame")
                        pass

                # Safely read the latest emotion from the global variable
                with emotion_lock:
                    emotion = latest_emotion

                # --- Overlay Data on Frame ---
                hr_display = heart_rate if isinstance(heart_rate, str) else f"{heart_rate:.1f} BPM"
                # cv2.putText(frame, f'Heart Rate: {hr_display}', (10, 30),
                #             cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2, cv2.LINE_AA)
                cv2.putText(frame, f'Emotion: {emotion}', (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2, cv2.LINE_AA)

                # --- Prepare Data Packet ---
                rgb_data = {
                    'r': mean_r,
                    'g': mean_g,
                    'b': mean_b,
                    'heart_rate': heart_rate,
                    'timestamp': time.time(),
                    'body_temprature': estimated_temp,
                    'emotion': emotion
                }
            
            # --- Broadcast & Stream ---
            # Every 3 frames, broadcast the numerical data to clients
            if frame_count % 3 == 0:
                broadcast_rgb_data(rgb_data)
            
            # Encode the processed frame (with text overlay) as a JPEG
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()

            # Yield the frame in MJPEG streaming format
            # This is what the web server sends to the browser
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

    finally:
        # --- Cleanup ---
        # This block always runs, even if an error occurs
        logger.debug("Cleaning up resources...")
        # Signal the emotion thread to stop
        stop_event.set()
        # Release the video capture device
        cap.release()
        logger.debug("Video capture released")