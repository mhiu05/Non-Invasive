// --- Biến toàn cục và Hằng số ---
let rgbChart;
let eventSource;
let isStreamActive = false;
let updateCount = 0;
const maxDataPoints = 100;

// --- Lấy các phần tử DOM ---
const uploadForm = document.getElementById("upload-form");
const uploadButton = document.getElementById("upload-button");
const videoInput = document.getElementById("video-input");
const fileLabel = document.getElementById("file-label");
const fileInputContainer = document.getElementById("file-input-container");
const errorContainer = document.getElementById("error-container");
const videoStream = document.getElementById("video-stream");

const heartRateEl = document.getElementById("heart-rate").querySelector("strong");
const bodyTempEl = document.getElementById("body-temperature").querySelector("strong");
const currentREl = document.getElementById("current-r");
const currentGEl = document.getElementById("current-g");
const currentBEl = document.getElementById("current-b");


// --- Hàm Khởi tạo ---

// Khởi tạo biểu đồ Chart.js
function initChart() {
    const ctx = document.getElementById('rgbChart').getContext('2d');
    rgbChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Red',
                data: [],
                borderColor: 'var(--metric-r)',
                backgroundColor: 'rgba(255, 68, 68, 0.2)',
                tension: 0.1,
                pointRadius: 0
            }, {
                label: 'Green',
                data: [],
                borderColor: 'var(--metric-g)',
                backgroundColor: 'rgba(68, 255, 68, 0.2)',
                tension: 0.1,
                pointRadius: 0
            }, {
                label: 'Blue',
                data: [],
                borderColor: 'var(--metric-b)',
                backgroundColor: 'rgba(68, 68, 255, 0.2)',
                tension: 0.1,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            scales: {
                x: { display: false },
                y: { beginAtZero: true, max: 255 }
            },
            plugins: {
                title: { display: true, text: 'RGB Signal Values (Real-time)' }
            }
        }
    });
}

// --- Hàm Xử lý Giao diện (UI) ---

// Hiển thị lỗi
function showError(message) {
    errorContainer.textContent = message;
    errorContainer.hidden = false;
}

// Ẩn lỗi
function hideError() {
    errorContainer.textContent = "";
    errorContainer.hidden = true;
}

// Cài đặt trạng thái loading cho nút bấm
function setButtonLoading(isLoading) {
    if (isLoading) {
        uploadButton.disabled = true;
        uploadButton.textContent = 'Đang xử lý...';
    } else {
        uploadButton.disabled = false;
        uploadButton.textContent = 'Upload and Stream';
    }
}

// Cập nhật giao diện khi chọn file
function updateFileInputLabel() {
    if (videoInput.files && videoInput.files[0]) {
        fileLabel.textContent = videoInput.files[0].name;
        fileInputContainer.classList.add('has-file');
    } else {
        fileLabel.textContent = 'Choose Video File';
        fileInputContainer.classList.remove('has-file');
    }
}

// Reset giao diện về trạng thái ban đầu
function resetUI() {
    heartRateEl.textContent = '-- BPM';
    bodyTempEl.textContent = '-- °C';
    currentREl.textContent = 'R: 0';
    currentGEl.textContent = 'G: 0';
    currentBEl.textContent = 'B: 0';
    videoStream.src = ""; // Dừng video stream cũ

    // Reset biểu đồ
    if (rgbChart) {
        rgbChart.data.labels = [];
        rgbChart.data.datasets[0].data = [];
        rgbChart.data.datasets[1].data = [];
        rgbChart.data.datasets[2].data = [];
        rgbChart.update();
    }
    
    // Reset bộ đếm
    updateCount = 0;
}

// --- Hàm Xử lý Dữ liệu và Kết nối ---

// Cập nhật giao diện với dữ liệu mới từ SSE
function handleRGBData(data) {
    if (data.heartbeat) return; // Bỏ qua tin nhắn heartbeat (nếu có)
    
    updateCount++;
    
    // Cập nhật các giá trị
    currentREl.textContent = `R: ${data.r}`;
    currentGEl.textContent = `G: ${data.g}`;
    currentBEl.textContent = `B: ${data.b}`;
    
    const hrText = typeof data.heart_rate === 'string' 
        ? data.heart_rate 
        : data.heart_rate.toFixed(1);
    heartRateEl.textContent = `${hrText} BPM`;
    
    if (data.body_temprature !== undefined) {
        bodyTempEl.textContent = `${data.body_temprature.toFixed(1)} °C`;
    }
    
    // Cập nhật biểu đồ
    rgbChart.data.labels.push(updateCount);
    rgbChart.data.datasets[0].data.push(data.r);
    rgbChart.data.datasets[1].data.push(data.g);
    rgbChart.data.datasets[2].data.push(data.b);
    
    // Giới hạn số điểm dữ liệu trên biểu đồ
    if (rgbChart.data.labels.length > maxDataPoints) {
        rgbChart.data.labels.shift();
        rgbChart.data.datasets.forEach(dataset => dataset.data.shift());
    }
    
    rgbChart.update('none'); // Cập nhật không có animation
}

// Bắt đầu kết nối Server-Sent Events (SSE)
function startSSEConnection() {
    if (eventSource) {
        eventSource.close();
    }
    
    eventSource = new EventSource('/rgb_stream');
    
    eventSource.onopen = () => console.log('SSE connection opened');
    
    eventSource.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            handleRGBData(data);
        } catch (error) {
            console.error('Error parsing SSE data:', error);
        }
    };
    
    eventSource.onerror = (error) => {
        console.error('SSE error:', error);
        // Tự động kết nối lại sau 3 giây
        setTimeout(() => {
            if (isStreamActive) {
                console.log('Attempting to reconnect...');
                startSSEConnection();
            }
        }, 3000);
    };
    isStreamActive = true;
}

// Dừng kết nối SSE
function stopSSEConnection() {
    isStreamActive = false;
    if (eventSource) {
        eventSource.close();
        eventSource = null;
        console.log('SSE connection closed');
    }
}

// Xử lý sự kiện submit form
async function handleFormSubmit(e) {
    e.preventDefault(); // Ngăn trang tải lại
    
    hideError(); // Xóa lỗi cũ
    setButtonLoading(true); // Bật trạng thái loading
    stopSSEConnection(); // Dừng stream cũ (nếu có)
    resetUI(); // Đặt lại giao diện

    const formData = new FormData(uploadForm);

    try {
        // 1. Tải video lên
        const uploadResponse = await fetch("/upload", {
            method: "POST",
            body: formData
        });

        if (!uploadResponse.ok) {
            throw new Error(`Video upload failed: ${uploadResponse.statusText}`);
        }

        // 2. Reset bộ lọc (Kalman filter) ở backend
        const resetResponse = await fetch("/set_variable", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ variable: "reset" })
        });

        if (!resetResponse.ok) {
            throw new Error(`Failed to reset variables: ${resetResponse.statusText}`);
        }

        // 3. Bắt đầu stream (sau một khoảng trễ nhỏ để backend sẵn sàng)
        // Đây là một "hack" nhỏ, nếu backend có cơ chế "ready" thì sẽ tốt hơn
        setTimeout(() => {
            // Thêm một tham số ngẫu nhiên để tránh trình duyệt cache ảnh
            videoStream.src = "/video_feed?" + new Date().getTime(); 
            startSSEConnection();
        }, 500); // 500ms delay

    } catch (err) {
        console.error(err);
        showError(`An error occurred: ${err.message}. Please try again.`);
    } finally {
        setButtonLoading(false); // Tắt trạng thái loading
    }
}

// --- Gán các Sự kiện (Event Listeners) ---

// Chạy khi toàn bộ HTML đã được tải
document.addEventListener('DOMContentLoaded', () => {
    initChart();
    uploadForm.addEventListener("submit", handleFormSubmit);
    videoInput.addEventListener('change', updateFileInputLabel);
});

// Dọn dẹp khi người dùng rời trang
window.addEventListener('beforeunload', stopSSEConnection);