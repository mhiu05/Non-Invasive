import cv2
import numpy as np
from scipy.signal import butter, filtfilt # type: ignore
from collections import deque
from sklearn.preprocessing import StandardScaler
import threading
import time
import queue
import logging
import tensorflow as tf
import os

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# constants 
BUFFER_SIZE = 1024
FPS = 30 
CONFIDENCE_THRESHOLD = 0.5 

# data buffers  
rgb_buffer = {'r': deque(maxlen=BUFFER_SIZE), 'g': deque(maxlen=BUFFER_SIZE), 'b': deque(maxlen=BUFFER_SIZE)}
hr_values = deque(maxlen=10)

# threading & streaming  
rgb_clients = []
current_rgb_data = {'r': 0, 'g': 0, 'b': 0, 'heart_rate': 75.0} 
rgb_data_lock = threading.Lock()

# kalman filter parameters 
kalman_hr = 75.0
kalman_p = 1.0
kalman_q = 0.01
kalman_r = 1.0

# Model initialization
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'face_detection_yunet_2023mar.onnx')

FACE_DETECTOR = None

try:
    FACE_DETECTOR = cv2.dnn.readNet(MODEL_PATH)
    
    if FACE_DETECTOR.empty():
        raise Exception("DNN Net is empty after loading.")
    
    logger.info("Face Detector (YuNet ONNX) initialized successfully.")

except Exception as e:
    logger.error(f"Error loading DNN model: {e}. Please ensure '{os.path.basename(MODEL_PATH)}' is in {BASE_DIR}")
    FACE_DETECTOR = None 


# ====== 1. Face Mask Creation  ======
def create_face_mask_with_colors(image):
    """
    Uses OpenCV DNN to detect faces and create a rectangular mask.
    """
    if FACE_DETECTOR is None:
        return None
        
    (h, w) = image.shape[:2]
    # USE NEW INPUT SIZE (fixed previous error)
    TARGET_SIZE = (320, 320) 
    
    # Create an input blob for the DNN
    blob = cv2.dnn.blobFromImage(
        cv2.resize(image, TARGET_SIZE), 
        1.0, 
        TARGET_SIZE, 
        (104.0, 177.0, 123.0), 
        swapRB=False, 
        crop=False
    )

    FACE_DETECTOR.setInput(blob)
    detections = FACE_DETECTOR.forward()

    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    face_detected = False

    # Get the detection array (YuNet returns a 3D array: [1, N, 15] or [1, 15, N])
    # We only need a 2D array [N, M]
    # np.squeeze removes dimensions of size 1 (like [0] and [1])
    detections = np.squeeze(detections).astype(float) 

    # If detections finds only one face, it might become a 1D array, 
    # so we check to ensure it remains 2D (NxM).
    if detections.ndim == 1:
        detections = np.expand_dims(detections, axis=0)

    # Loop over the detections (now a 2D array: [N, 15])
    for detection in detections:
        # In YuNet, confidence might be the 15th element (index 14) 
        # YUNET MODELS TYPICALLY HAVE THE STRUCTURE: [x1, y1, x2, y2, score, ...]
        # We assume confidence is the 5th element (index 4)
        confidence = detection[4] 

        if confidence > CONFIDENCE_THRESHOLD:
            # The box coordinates are usually the first elements
            startX = int(detection[0] * w)
            startY = int(detection[1] * h)
            endX = int(detection[2] * w)
            endY = int(detection[3] * h)

            # Ensure the box coordinates are valid
            if startX < 0: startX = 0
            if startY < 0: startY = 0
            if endX > w: endX = w
            if endY > h: endY = h

            # Create a rectangular mask covering the face
            padding_y = int((endY - startY) * 0.1)
            startY = max(0, startY - padding_y)

            cv2.rectangle(mask, (startX, startY), (endX, endY), 255, -1)
            
            face_detected = True
            break # Process only the first (most confident) face

    if face_detected:
        masked_face = cv2.bitwise_and(image, image, mask=mask)
        return masked_face
    return None


# ====== 2. Skin Segmentation ======
def skin_segmentation(face_mask):
    """Segments skin color within the face mask."""
    
    # Convert the face mask image from BGR to HSV color space
    hsv = cv2.cvtColor(face_mask, cv2.COLOR_BGR2HSV)

    # Define the lower and upper bounds for skin color detection in HSV
    # These bounds might need adjustment depending on lighting conditions and ethnicity
    lower_skin = np.array([0, 20, 70], dtype=np.uint8)
    upper_skin = np.array([20, 255, 255], dtype=np.uint8)
    
    # Create a binary mask where white pixels represent skin and black pixels do not
    skin_mask = cv2.inRange(hsv, lower_skin, upper_skin)
    
    # Apply the skin mask to the original face_mask using a bitwise-AND operation
    # This keeps only the skin pixels from the face_mask
    return cv2.bitwise_and(face_mask, face_mask, mask=skin_mask)


# ====== 3. Signal Processing Functions ======
def blackout_outside_dynamic_threshold(frame, lower_factor=0.48, upper_factor=1.74):
    """Filters out pixels that are too dark (shadows) or too bright (specular glare)."""
    
    # Convert the frame to grayscale to work with pixel intensities
    gray_image = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Select only non-black pixels (which are assumed to be part of the skin mask)
    non_zero_pixels = gray_image[gray_image != 0]

    # Calculate the median intensity value. 
    # Using median is more robust to outliers (like very bright spots) than mean.
    average_value = np.median(non_zero_pixels) if non_zero_pixels.size > 0 else 0

    # Calculate the dynamic lower and upper intensity thresholds based on the median
    lower_threshold = max(0, int(average_value * lower_factor))
    upper_threshold = min(255, int(average_value * upper_factor))

    # Create a mask where 'True' indicates pixels within the valid intensity range
    mask = (gray_image >= lower_threshold) & (gray_image <= upper_threshold)

    # Create a new black frame with the same dimensions as the original
    updated_frame = np.zeros_like(frame)
    
    # Use the mask to copy only the "good" pixels from the original frame to the new frame
    updated_frame[mask] = frame[mask]

    return updated_frame


# ====== 4. RGB Signal Extraction ======
def extract_rgb_signals(frame):
    """Extracts the average R, G, and B values from the frame."""
    
    # Select all pixels that are not black (i.e., pixels that are part of the skin mask)
    # It checks this by summing the R, G, and B values (axis=2) and keeping only those > 0.
    face_pixels = frame[frame.sum(axis=2) > 0]

    # If no skin pixels were found (e.g., face moved out of frame)
    if len(face_pixels) == 0:
        logger.debug("No face pixels detected")
        return (0, 0, 0)
    
    # Calculate the mean value for each channel across all skin pixels
    # In OpenCV (BGR):
    # face_pixels[:, 2] is the Red channel
    # face_pixels[:, 1] is the Green channel
    # face_pixels[:, 0] is the Blue channel
    mean_r = int(np.mean(face_pixels[:, 2]))
    mean_g = int(np.mean(face_pixels[:, 1]))
    mean_b = int(np.mean(face_pixels[:, 0]))

    logger.debug(f"RGB signals: R={mean_r}, G={mean_g}, B={mean_b}")
    
    # Return the average RGB values as a tuple
    return (mean_r, mean_g, mean_b)


# ======= 5. Heart Rate Computation ======
def set_kalman_defaults():
    """Clears data buffers and resets Kalman filter parameters."""
    global kalman_hr, kalman_p
    
    # Clear the RGB signal buffers
    rgb_buffer['r'].clear()
    rgb_buffer['g'].clear()
    rgb_buffer['b'].clear()
    
    # Clear the historical heart rate buffer
    hr_values.clear()

    # Reset Kalman filter estimates to default (75 BPM)
    kalman_hr = 75.0
    kalman_p = 1.0

def normalize_input_for_lstm(g_buffer):
    """
    Prepares the raw GREEN CHANNEL (G) signal for the 1-channel LSTM model.
    """
    
    # Convert deque to numpy array
    g_np = np.array(g_buffer, dtype=np.float32)

    # Reshape for StandardScaler: (N,) -> (N, 1)
    g_reshaped = g_np.reshape(-1, 1)

    # Apply standardization (zero-mean, unit-variance)
    scaler_x = StandardScaler()
    normalized_signal = scaler_x.fit_transform(g_reshaped).flatten()
    
    # 3. Ensure it has a length of 1024 (padding case)
    current_len = len(normalized_signal)
    if current_len < BUFFER_SIZE:
        # Apply padding (add zeros to the START)
        padding = BUFFER_SIZE - current_len
        normalized_signal = np.pad(normalized_signal, (padding, 0), 'constant', constant_values=0.0)

    # 4. Add batch and channel dimensions (shape: [1, BUFFER_SIZE, 1])
    final_input = np.expand_dims(normalized_signal, axis=0)  # Shape [1, 1024]
    final_input = np.expand_dims(final_input, axis=-1)       # Shape [1, 1024, 1]
    
    return final_input

def compute_heart_rate(g_buffer, model):
    """
    Computes heart rate using ONLY THE GREEN CHANNEL (G).
    This function now assumes the input is processed and padded.
    """
    global kalman_hr, kalman_p
    
    # 1. Prepare input for LSTM (handles padding and scaling)
    lstm_input = normalize_input_for_lstm(g_buffer) 

    # 2. Run prediction with LSTM (Denoising)
    try:
        clean_vpg_batch = model.predict(lstm_input)
    except Exception as e:
        logger.error(f"Error during LSTM prediction: {e}")
        return kalman_hr
    
    # Extract the 1D signal from the batch output
    filtered_signal = clean_vpg_batch[0, :, 0]
    
    # 3. Apply FFT (Fast Fourier Transform)
    fft_spectrum = np.fft.rfft(filtered_signal)
    freqs = np.fft.rfftfreq(len(filtered_signal), d=1/FPS)
    
    # Define valid frequency range for human HR (0.92Hz=55BPM, 2.0Hz=120BPM)
    valid_range = (freqs >= 0.92) & (freqs <= 2.0) 
    
    # Check for valid spectrum data
    if not any(valid_range) or len(np.abs(fft_spectrum[valid_range])) == 0:
        logger.debug("No valid frequencies/spectrum, returning current HR")
        return kalman_hr
        
    # Find the peak frequency
    valid_spectrum = np.abs(fft_spectrum[valid_range])
    peak_freq = freqs[valid_range][np.argmax(valid_spectrum)]
    
    # Convert frequency (Hz) to BPM
    bpm = peak_freq * 60
    
    # Sanity check
    if bpm < 40:
        bpm = kalman_hr 

    # 4. Kalman Filter (Smoothing)
    hr_values.append(bpm)
    bpm_smoothed = np.mean(hr_values) 

    # Kalman update steps
    kalman_p += kalman_q
    kalman_k = kalman_p / (kalman_p + kalman_r)
    kalman_hr = kalman_hr + kalman_k * (bpm_smoothed - kalman_hr) 
    kalman_p = (1 - kalman_k) * kalman_p
    
    return kalman_hr


def broadcast_rgb_data(data):
    """Broadcasts data packet to all connected clients."""
    
    # Acquire the thread lock to ensure thread-safe access to global variables
    with rgb_data_lock:
        global current_rgb_data
        # Update the global variable holding the most recent data
        current_rgb_data = data

        logger.debug(f"Broadcasting RGB data: {data}")

        # Create a list to track clients that seem disconnected
        disconnected_clients = []

        # Iterate over a copy of the list of connected clients
        # Each 'client_queue' is a queue.Queue object for a specific client
        for client_queue in rgb_clients:
            try:
                # Try to put the new data into the client's queue
                # block=False/timeout=0.1 prevents this loop from blocking
                # if a client's queue is full.
                client_queue.put(data, timeout=0.1)
            except queue.Full:
                # If the queue is full (client isn't processing data fast enough),
                # assume the client is disconnected or lagging.
                disconnected_clients.append(client_queue)
                logger.debug("Client queue full, marking for removal.")

        # Remove all disconnected/lagging clients from the active list
        for client in disconnected_clients:
            if client in rgb_clients:
                rgb_clients.remove(client)


MIN_CALC_FRAMES = 300 

def hr_calculator_thread(model):
    """
    A separate thread dedicated to running LSTM and FFT calculations.
    It runs once per second to update the heart rate.
    """
    global current_rgb_data, rgb_buffer, kalman_hr
    
    logger.info("HR calculation thread started.")
    
    while True:
        time.sleep(1.0) # Wait for 1 second
        
        g_buffer_copy = []

        # ----- Start lock region -----
        with rgb_data_lock:
            # Check if the buffer is sufficiently full
            if len(rgb_buffer['g']) < MIN_CALC_FRAMES:
                logger.debug(f"Buffer not full, waiting for {MIN_CALC_FRAMES} frames: {len(rgb_buffer['g'])}/{MIN_CALC_FRAMES}")
                continue 
            
            g_buffer_copy = rgb_buffer['g'].copy()
        # ----- End lock region -----

        try:
            heart_rate = compute_heart_rate(
                g_buffer_copy,
                model
            )
            
            with rgb_data_lock:
                current_rgb_data['heart_rate'] = heart_rate
                logger.debug(f"Updated HR: {heart_rate:.1f} BPM")

        except Exception as e:
            logger.error(f"Error in HR calculation thread: {e}")


# ====== Main Video Processing Function ======
def generate_gray_frames(path):
    """
    Processes the video, extracts signals, and handles display.
    Heart rate calculation is delegated to a separate thread.
    """
    cap = cv2.VideoCapture(path)
    frame_count = 0
    
    if FACE_DETECTOR is None:
        logger.error("Face Detector failed to load.")
        cap.release()
        return

    # --- Load the LSTM model ---
    try:
        logger.info("Loading LSTM model ...")
        model_path = os.path.join(BASE_DIR, 'my_lstm_denoising_model.h5') 
        loaded_model = tf.keras.models.load_model(model_path, compile=False)
        logger.info("Complete load model LSTM.")
    except Exception as e:
        logger.error(f"Error load LSTM model : {e}")
        cap.release()
        return

    # --- START HR CALCULATION THREAD ---
    # Run the hr_calculator_thread function on a background thread
    # daemon=True means the thread will shut down automatically when the main program stops
    hr_thread = threading.Thread(target=hr_calculator_thread, args=(loaded_model,), daemon=True)
    hr_thread.start()
    
    # --- Main processing loop ---
    try:
        while cap.isOpened():
            success, frame = cap.read()
            if not success:
                logger.debug("Failed to read frame or end of video")
                break 

            frame_count += 1

            # --- 1. Face Detection ---
            face_mask = create_face_mask_with_colors(frame)
            
            # Initialize display variable
            hr_display = "Detecting..."
            
            # --- 2. Check if face was found ---
            if face_mask is None or not np.any(face_mask):
                logger.debug("No face detected in frame")
                cv2.putText(frame, "No face detected", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                
                rgb_data = {'r': 0, 'g': 0, 'b': 0, 'heart_rate': 0.0}
                set_kalman_defaults() # Consider resetting buffer here
            
            else:
                # --- 3. rPPG Pipeline (signal extraction only) ---
                skin_segmented = skin_segmentation(face_mask)
                face = blackout_outside_dynamic_threshold(skin_segmented)
                mean_r, mean_g, mean_b = extract_rgb_signals(face)

                # --- 4. Update buffer (under lock) ---
                with rgb_data_lock:
                    rgb_buffer["r"].append(mean_r)
                    rgb_buffer["g"].append(mean_g)
                    rgb_buffer["b"].append(mean_b)
                    
                    # Get the LATEST heart rate calculated by the other thread
                    heart_rate = current_rgb_data['heart_rate'] 
                
                # --- 5. Display & Prepare Data ---
                
                # Check if we are still in the initial detection phase
                # We use 'g' buffer to be consistent with the HR calculator
                is_detecting = (heart_rate == 75.0 or len(rgb_buffer['g']) < MIN_CALC_FRAMES) 

                hr_display = ""       # Variable for video overlay
                broadcast_hr = 0.0    # Variable for UI broadcast (must be a number)

                if is_detecting:
                    hr_display = "Detecting..."
                    broadcast_hr = 0.0 # Send 0.0 to UI
                else:
                    hr_display = f"{heart_rate:.1f} BPM"
                    broadcast_hr = heart_rate # Send the actual calculated value

                # Draw the text on the video frame
                cv2.putText(frame, f'Heart Rate: {hr_display}', (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2, cv2.LINE_AA)

                # Prepare the data packet for broadcasting
                rgb_data = {
                    'r': mean_r,
                    'g': mean_g,
                    'b': mean_b,
                    'heart_rate': broadcast_hr, # Use the new broadcast value
                    'timestamp': time.time(),
                }
            
            # --- 6. Broadcast Data ---
            if frame_count % 3 == 0:
                broadcast_rgb_data(rgb_data)
            
            # --- 7. Yield Frame for Streaming ---
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

    finally:
        logger.debug("Cleaning up resources...")
        cap.release()
        logger.debug("Video capture released")