// --- Biến toàn cục và Hằng số ---
let rgbChart;
let eventSource;
let isStreamActive = false;
let updateCount = 0;
const maxDataPoints = 100;

// --- Lấy các phần tử DOM ---
const uploadForm = document.getElementById("upload-form");
const uploadButton = document.getElementById("upload-button");
const videoInput = document.getElementById("video-input");
const fileLabel = document.getElementById("file-label");
const fileInputContainer = document.getElementById("file-input-container");
const errorContainer = document.getElementById("error-container");
const videoStream = document.getElementById("video-stream");

// SỬA ĐỔI: Chỉ giữ lại heartRateEl
const heartRateEl = document.getElementById("heart-rate").querySelector("strong");
// ĐÃ LOẠI BỎ: currentREl, currentGEl, currentBEl

// --- Hàm Khởi tạo ---

// Khởi tạo biểu đồ Chart.js
function initChart() {
    const ctx = document.getElementById('rgbChart').getContext('2d');
    rgbChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Red',
                data: [],
                borderColor: 'var(--metric-r)',
                backgroundColor: 'rgba(255, 68, 68, 0.2)',
                borderWidth: 2, // Làm dày đường
                tension: 0.1,
                pointRadius: 0
            }, {
                label: 'Green',
                data: [],
                borderColor: 'var(--metric-g)',
                backgroundColor: 'rgba(68, 255, 68, 0.2)',
                borderWidth: 2, // Làm dày đường
                tension: 0.1,
                pointRadius: 0
            }, {
                label: 'Blue',
                data: [],
                borderColor: 'var(--metric-b)',
                backgroundColor: 'rgba(68, 68, 255, 0.2)',
                borderWidth: 2, // Làm dày đường
                tension: 0.1,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            scales: {
                x: { display: false },
                y: { beginAtZero: true, max: 255 }
            },
            plugins: {
                title: { display: true, text: 'RGB Signal Values (Real-time)' }
            }
        }
    });
}

// --- Hàm Xử lý Giao diện (UI) ---

// Hiển thị lỗi
function showError(message) {
    errorContainer.textContent = message;
    errorContainer.hidden = false;
}

// Ẩn lỗi
function hideError() {
    errorContainer.textContent = "";
    errorContainer.hidden = true;
}

// Cài đặt trạng thái loading cho nút bấm
function setButtonLoading(isLoading) {
    if (isLoading) {
        uploadButton.disabled = true;
        uploadButton.textContent = 'Processing...';
    } else {
        uploadButton.disabled = false;
        uploadButton.textContent = 'Upload and Stream';
    }
}

// Cập nhật giao diện khi chọn file
function updateFileInputLabel() {
    if (videoInput.files && videoInput.files[0]) {
        fileLabel.textContent = videoInput.files[0].name;
        fileInputContainer.classList.add('has-file');
    } else {
        fileLabel.textContent = 'Choose Video File';
        fileInputContainer.classList.remove('has-file');
    }
}

// Reset giao diện về trạng thái ban đầu
function resetUI() {
    // SỬA ĐỔI: Cập nhật logic reset
    heartRateEl.textContent = 'Detecting...';
    heartRateEl.parentElement.classList.remove('active'); // Xóa class "active" (sẽ định nghĩa trong CSS)
    videoStream.src = ""; // Dừng video stream cũ

    // Reset biểu đồ
    if (rgbChart) {
        rgbChart.data.labels = [];
        rgbChart.data.datasets[0].data = [];
        rgbChart.data.datasets[1].data = [];
        rgbChart.data.datasets[2].data = [];
        rgbChart.update();
    }
    
    // Reset bộ đếm
    updateCount = 0;
}

// --- Hàm Xử lý Dữ liệu và Kết nối ---

/**
 * Cập nhật giao diện với dữ liệu mới từ SSE
 * ĐÂY LÀ HÀM QUAN TRỌNG ĐÃ ĐƯỢC SỬA
 */
function handleRGBData(data) {
    if (data.heartbeat) return; // Bỏ qua tin nhắn heartbeat (nếu có)
    
    updateCount++;
    
    // SỬA ĐỔI: Cập nhật nhịp tim
    // Logic mới: nếu heart_rate <= 0, hiển thị "Detecting...".
    // Ngược lại, hiển thị giá trị.
    if (data.heart_rate <= 0) {
        heartRateEl.textContent = "Detecting...";
        heartRateEl.parentElement.classList.remove('active');
    } else {
        heartRateEl.textContent = `${data.heart_rate.toFixed(1)} BPM`;
        heartRateEl.parentElement.classList.add('active'); // Thêm class 'active'
    }

    // ĐÃ LOẠI BỎ: Cập nhật text R, G, B
    
    // Cập nhật biểu đồ (Vẫn giữ nguyên)
    rgbChart.data.labels.push(updateCount);
    rgbChart.data.datasets[0].data.push(data.r);
    rgbChart.data.datasets[1].data.push(data.g);
    rgbChart.data.datasets[2].data.push(data.b);
    
    // Giới hạn số điểm dữ liệu trên biểu đồ
    if (rgbChart.data.labels.length > maxDataPoints) {
        rgbChart.data.labels.shift();
        rgbChart.data.datasets.forEach(dataset => dataset.data.shift());
    }
    
    rgbChart.update('none'); // Cập nhật không có animation
}

// Bắt đầu kết nối Server-Sent Events (SSE)
function startSSEConnection() {
    if (eventSource) {
        eventSource.close();
    }
    
    eventSource = new EventSource('/rgb_stream');
    
    eventSource.onopen = () => console.log('SSE connection opened');
    
    eventSource.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            handleRGBData(data);
        } catch (error) {
            console.error('Error parsing SSE data:', error);
        }
    };
    
    eventSource.onerror = (error) => {
        console.error('SSE error:', error);
        // Tự động kết nối lại sau 3 giây
        setTimeout(() => {
            if (isStreamActive) {
                console.log('Attempting to reconnect...');
                startSSEConnection();
            }
        }, 3000);
    };
    isStreamActive = true;
}

function stopSSEConnection() {
    isStreamActive = false;
    if (eventSource) {
        eventSource.close();
        eventSource = null;
        console.log('SSE connection closed');
    }
}

async function handleFormSubmit(e) {
    e.preventDefault(); 
    
    hideError(); 
    setButtonLoading(true);
    stopSSEConnection(); 
    resetUI(); // Reset UI về trạng thái "Detecting..."

    const formData = new FormData(uploadForm);

    try {
        const uploadResponse = await fetch("/upload", {
            method: "POST",
            body: formData
        });

        if (!uploadResponse.ok) {
            throw new Error(`Video upload failed: ${uploadResponse.statusText}`);
        }

        const resetResponse = await fetch("/set_variable", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ variable: "reset" })
        });

        if (!resetResponse.ok) {
            throw new Error(`Failed to reset variables: ${resetResponse.statusText}`);
        }

        setTimeout(() => {
            videoStream.src = "/video_feed?" + new Date().getTime(); 
            startSSEConnection();
        }, 500); 

    } catch (err) {
        console.error(err);
        showError(`An error occurred: ${err.message}. Please try again.`);
    } finally {
        setButtonLoading(false); 
    }
}


document.addEventListener('DOMContentLoaded', () => {
    initChart();
    uploadForm.addEventListener("submit", handleFormSubmit);
    videoInput.addEventListener('change', updateFileInputLabel);
});

window.addEventListener('beforeunload', stopSSEConnection);